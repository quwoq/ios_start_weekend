import Cocoa

print("😜")
print("月火") //알트 + 엔터임둥

