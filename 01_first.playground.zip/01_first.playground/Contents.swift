import Cocoa

var greeting = "Hello, playground"

print("Hello. This is Swift.")
print(2+3*4)
//print(Hello)  한줄주석
/*
 여러줄 주석
 /*
  // 이렇게도 가넝한
  */
  
 */

print("여긴 참나무 어쩌구가\t 살지")
print("나폴레오옹은 \n'이산이아닌대' 라고생각했다")

//print("나폴레옹은 "불이야" 외쳤다")  오류나자나
print("나폴레옹은 \"불이야\" 외쳤다") //" 이거 넣고 싶으면 앞에 역슬래시 넣으면 되자나 :제어문자

print(2+3, 100, "안녕")

print("아기상어", terminator: " -> ") //줄 안바꾸고 싶어서 terminator 쓴거임.
print("아기상어", terminator: " \t ")
print("아기상어")
print("아기상어")
print("아기상어")
